<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Science</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>home |AOA</title>
   
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/AOA.png">
    <!--<link rel="shortcut icon" href="images/ico/favicon.ico">  need to change-->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
							
							
								
							
								<li><a href="contact.php"><i class="fa fa-linkedin">Contact us</i></a></li>
							<!--	<li><a href="login.php"><i class="fa fa-linkedin">login</i></a></li>-->
							<li><a href="login1.php"><i class="fa fa-linkedin">login</i></a></li>
							<li><a href="logout.php"><i class="fa fa-linkedin">logout</i></a></li>
							
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
                        <a href="#"><img src="images/android-chrome-192x192.png" alt="aoa.jpeg" height='40' /></a>
					   
						 
						
					
					</div>
					</div>
					<div class="col-md-8 clearfix">
						<div class="shop-menu clearfix pull-right">
							<ul class="nav navbar-nav">
							<!--<li><a href="welcome.php"><i class="fa fa-twitter">Home</i></a></li>-->
							<!--<li><a href="#"><i class="fa fa-crosshairs"></i> Checkout</a></li> payment page-->
							<!--<li><a href="#"><i class="fa fa-shopping-cart"></i> Cart</a></li>-->
							<!--	<li><a href="news.php"><i class="fa fa-linkedin">News</i></a></li>-->
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
     
		<font face= Adobe Gothic Std"font size="5"font color="ORANGE"><b>
					  	<marquee>WELCOME TO AOA WHERE YOU CAN CLEAR YOUR DOUBTS RELATED TO RESEARCH PAPERS WITH MENTORS/MATES😄😄😄!!!!!</marquee></b></font>


      <!--chatbot-->
      <script type='text/javascript'> (function () {function async_load() {var bt_ads = document.createElement('script'); bt_ads.setAttribute('async', true); bt_ads.setAttribute('type', 'text/javascript'); bt_ads.src = 'https://usbot.surbo.io/static/1.0.1/js/custom/widget_surbo.js?id=6235c0df5476131c75bb6a7a&srb_1=&srb_2=&srb_3= &screen_size=normal &widget_location=left &widget_popup_time=&type=icon&fname=&lname=&email='; var node = document.getElementsByTagName('script')[0]; node.parentNode.insertBefore(bt_ads, node); } if (window.attachEvent) window.attachEvent('onload', async_load); else window.addEventListener('load', async_load, false); })(); </script> <div id='bot-container'> </div>
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
							<!--	<li><a href="#" class="active">Home</a></li> -->
								<li class="dropdown"><a href="#">Menu<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="topics.php">Topics</a></li> <!--buycart.php-->
										<li><a href="mentor_info.php">Mentors</a></li>
                                        <li><a href="collab.php">Collab With Student</a></li>
									<!--	<li><a href="cart.php">Cart</a></li>--> 
									
                                    </ul>
                                </li> 
								
						</div>
					</div>
				<!--	<div class="col-sm-3">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search"/>
						</div> -->
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
						<!--	<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li> --><!---need to remove this-->
						</ol>
                        <!----->
                        <div class="carousel-inner">
							<section>
							<div class="item active">
								<div class="col-sm-6">
									<h1><span>AOA</span></h1>
									<h2>SPORTS </h2>
									<p>Want help in writing research paper related to SPORTS this website for you </p>
									<button type="button" class="btn btn-default get">upcoming</button>
								</div>
								<div class="col-sm-6">
									<img src="https://images.unsplash.com/photo-1530549387789-4c1017266635?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHNwb3J0c3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							</section>
							<section>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>AOA</span></h1>
									<h2>DATA SCIENCE</h2>
									<p>Want help in writing research paper related to DATA SCIENCE this website for you </p>
									<button type="button" class="btn btn-default get">upcomin</button>
								</div>
								<div class="col-sm-6">
									<img src="https://thumbs.dreamstime.com/z/modern-robot-isolated-d-illustration-white-background-modern-robot-d-illustration-white-background-isolated-132424432.jpg" class="girl img-responsive" alt="" />
								
								</div>
							</div>
							</section>
							<section>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>AOA</span></h1>
									<h2>LANGUAGE</h2>
									<p>Want help in writing research paper related to LANGUAGES this website is for you. You can collaborate with different mentors, students for help building your own research paper by your choice of mentor.</p>
									<button type="button" class="btn btn-default get">upcoming</button>
								</div>
								<div class="col-sm-6">
									<img src="https://media.istockphoto.com/photos/book-and-glowing-letters-picture-id522513933?b=1&k=20&m=522513933&s=170667a&w=0&h=j18tG6MV90Uops0LhnjPJFgpWB6AnJu4qEP5IQP9h7g=" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							</section>
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	<!--
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr--
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#sportswear">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											HEADPHONES
										</a>
									</h4>
								</div>
								<div id="headphones" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="headphones.php">Headphones </a></li>
											
											
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#mens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											PHONES
										</a>
									</h4>
								</div>
								<div id="phones" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="phones.php">Phones</a></li>
											
											
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#womens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											CLOTHING
										</a>
									</h4>
								</div>
								<div id="womens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="clothingm.php">MEN</a></li>
											<li><a href="clothingw.php">WOMEN</a></li>
											
										
										</ul>
									</div>
								</div>
							</div>
						
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="laptops.php">LAPTOPS</a></h4>
								</div>
							</div>
							
						</div><!--/category-products-->
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>