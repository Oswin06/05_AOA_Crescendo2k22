
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Enroll student for collab </title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/favicon.ico"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
							<!--	<li><a href="selling.php"><i class="fa fa-facebook"></i></a></li>-->
								<li><a href="welcome.php"><i class="fa fa-twitter">Home</i></a></li>
								<li><a href="logout.php"><i class="fa fa-linkedin">logout</i></a></li>
								<li><a href="view_property.php"><i class="fa fa-linkedin">view auction</i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
							<a href="#"><img src="images/android-chrome-192x192.png" alt="shar.jpeg" height='40' /></a>
					
						</div>
					</div>



</header><!--/header-->


<?php

if(isset($_POST['post'])){

    include 'config.php';
     //done changes
    $name=$_POST['name'];
    
    $phone_no=$_POST['phone_no'];
    $linkedin_id=$_POST['linkedin_id'];
    $experty=$_POST['experty'];
    $email=$_POST['email'];

   

    $sql = "INSERT INTO student(name,phone_no,linkedin_id,experty,email)
   VALUES('$name','$phone_no','$linkedin_id','$experty','$email')";
   $result = mysqli_query($conn,$sql);
//  if(mysqli_num_rows($result)==1){
   header('Location: welcome.php? p\Post Successfully!');
   exit();
 // }else{
  //    echo 'Error!';
  
 // }


}


?>

<div class="container">
  <h2><center>add student</center></h2>
  <form action="collab.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="name"> Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" required>
    </div>
    <div class="form-group">
      <label for="phone_no">Phone no:</label>
      <input type="text" class="form-control" id="phone_no" placeholder="Enter phone_no" name="phone_no" required>
    </div>
    <div class="form-group">
      <label for="linkedin_id">linkedin id:</label>
      <input type="text" class="form-control" id="linkedin_id" placeholder="Enter ur linkedin_id" name="linkedin_id" required>
    </div>
    <div class="form-group">
      <label for="experty">experty:</label>
      <input type="text" class="form-control" id="experty" placeholder="Enter ur experty" name="experty" required>
    </div>
    
    <div class="form-group">
      <label for="email">email:</label>
      <input type="text" class="form-control" id="email" name="email" placeholder="enter email" required>
    </div>

   
    <input type="submit" name="post" class="btn btn-primary pull-right" value="post">
       
  </form>
</div>



    
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	
	<script src="js/contact.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
