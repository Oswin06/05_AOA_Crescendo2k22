const Button = document.querySelector('#button');

Button.addEventListener('click', function () {
    alert("CONTACT ON GIVEN E-MAIL AND PHONE NUMBER FOR MENTORSHIP");
})