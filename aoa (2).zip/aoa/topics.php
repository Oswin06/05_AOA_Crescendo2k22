<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Reasearch Papers</title>
    <link rel="stylesheet" href="style_men.css">
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
        <div class="collapse navbar-collapse" id="expandme">
            <div class="navbar-nav">
                <a href="welcome.php" class="nav-item nav-link">Home</a>
                <a href="research.php" class="nav-item nav-link">Research</a>
                <a href="#" class="nav-item nav-link">Contact</a>
            </div>
        </div>
    </nav>
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="#">Home</a>
        <a class="nav-link" href="#">Features</a>
        <a class="nav-link" href="#">Pricing</a>
        <a class="nav-link disabled">Disabled</a>
      </div>
    </div>
  </div>
</nav>
<div class="row">
        <div class="col-6 offset-3">
            <div class="card">
                <img src="https://mentor.unm.edu/img/home/mentoring-tips.jpg" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">LIST OF MENTORS</h5>
                    <p class="card-text">
                        
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        1000+ mentors 
                    </li>
                  
                </ul>
                <div class="card-body">
                    <form class="d-inline" action="list_of_mentors.php" >
                        <button class="btn btn-danger">View</button>
                    </form>
                </div>
                <div class="card-footer text-muted">
                    Last Updated - 15 days ago
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-6 offset-3">
            <div class="card">
               <img src="https://th.bing.com/th/id/R.294ed07dc0c0216c1f3943307d851832?rik=oAOwMNfqqCOApw&riu=http%3a%2f%2fwww.gettingsmart.com%2fwp-content%2fuploads%2f2018%2f10%2fcollab.jpg&ehk=om%2bYBDhglvKWJU%2bxzt5NIGsAqHZZ1e0o0L9cZkROLvg%3d&risl=&pid=ImgRaw&r=0" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">LIST OF STUDENTS WITH WHOM YOU COLLAB</h5>
                    <p class="card-text">
                        
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        1000+ Students 
                    </li>
                 
                </ul>
                <div class="card-body">
                    <form class="d-inline" action="student_collab_info.php" >
                        <button class="btn btn-danger">View</button>
                    </form>
                </div>
                <div class="card-footer text-muted">
                    Last Updated - 10 days ago
                </div>
            </div>
        </div>
    </div>
   

    <script src="app.js"></script>
</body>
</html>