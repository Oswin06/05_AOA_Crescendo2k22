<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Reasearch Papers</title>
    <link rel="stylesheet" href="style_men.css">
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark fixed-top">
        <div class="collapse navbar-collapse" id="expandme">
            <div class="navbar-nav">
                <a href="Home" class="nav-item nav-link">Home</a>
                <a href="mentor.php" class="nav-item nav-link">Research</a>
                <a href="Home" class="nav-item nav-link">Contact</a>
            </div>
        </div>
    </nav>
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="#">Home</a>
        <a class="nav-link" href="#">Features</a>
        <a class="nav-link" href="#">Pricing</a>
        <a class="nav-link disabled">Disabled</a>
      </div>
    </div>
  </div>
</nav>
<div class="row">
        <div class="col-6 offset-3">
            <div class="card">
                <img src="https://media.istockphoto.com/photos/data-science-inscription-against-laptop-and-code-background-picture-id1360381528?b=1&k=20&m=1360381528&s=170667a&w=0&h=jaVTt0-gTmuz20WserPKyTfmm_QWRtL89NpObHPV2Xo=" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Data Science</h5>
                    <p class="card-text">
                        
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        1000+ mentors 
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-6 offset-3">
            <div class="card">
               <img src="https://media.istockphoto.com/photos/huge-multi-sports-collage-athletics-tennis-soccer-basketball-etc-picture-id1364045027?b=1&k=20&m=1364045027&s=170667a&w=0&h=NUGMGxltaLboXnndpuxgCfGunEp4S9B-mZsEulyqOmU=" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Sports</h5>
                    <p class="card-text">
                        
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        1000+ mentors 
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-6 offset-3">
            <div class="card">
                <img src="https://images.unsplash.com/photo-1614107151538-f4510e697ba8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjB8fGxhbmd1YWdlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Language</h5>
                    <p class="card-text">
                        
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        1000+ mentors 
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-6 offset-3">
            <div class="card">
                <img src="https://media.istockphoto.com/photos/bulb-with-equations-on-the-wall-picture-id1299492399?b=1&k=20&m=1299492399&s=170667a&w=0&h=pcBH73CriPTg3y04UAJWLE3Du4JBndcq-MwFi9TZ-4A=" class=" card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Mathematics</h5>
                    <p class="card-text">
                        
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        1000+ mentors 
                    </li>
                </ul>            
            </div>
        </div>
    </div>

    <script src="app.js"></script>
</body>
</html>