const Button1 = document.querySelector('#button1');

Button1.addEventListener('click', function () { 
    alert("CONTACT ON GIVEN E-MAIL AND PHONE NUMBER FOR COLLABORATION");
})